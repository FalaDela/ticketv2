const { Client, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events, EmbedBuilder } = require('discord.js');
const config = require('./config.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

client.once('ready', () => {
  console.log(`🔥 Bot online como ${client.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isButton()) return;

  const logChannel = await client.channels.fetch(config.ticketLogChannelId).catch(() => null);

  if (interaction.customId === 'open_ticket') {
    const existing = interaction.guild.channels.cache.find(ch =>
      ch.isThread() &&
      ch.name.includes(interaction.user.username) &&
      !ch.archived
    );

    if (existing) {
      return interaction.reply({ content: '⚠️ Você já tem um ticket aberto.', ephemeral: true });
    }

    const thread = await interaction.channel.threads.create({
      name: `🎫・ticket-${interaction.user.username}`,
      autoArchiveDuration: 1440,
      reason: 'Novo ticket',
      type: 11
    });

    await thread.members.add(interaction.user.id);

    await thread.send({
      content: `<@${interaction.user.id}> abriu um ticket.`,
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Fechar Ticket')
            .setStyle(ButtonStyle.Danger)
        )
      ]
    });

    if (logChannel) {
      const embed = new EmbedBuilder()
        .setTitle('🎟️ Ticket Aberto')
        .addFields(
          { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.tag})` },
          { name: 'Canal', value: `<#${thread.id}>` },
          { name: 'Data', value: `<t:${Math.floor(Date.now() / 1000)}:F>` }
        )
        .setColor('Green');
      logChannel.send({ embeds: [embed] });
    }

    return interaction.reply({ content: `✅ Ticket criado: <#${thread.id}>`, ephemeral: true });
  }

  if (interaction.customId === 'close_ticket') {
    if (!interaction.channel.isThread()) return;

    const closedBy = interaction.user;

    await interaction.channel.send('🚪 Ticket será arquivado em 5 segundos...');
    
    setTimeout(async () => {
      await interaction.channel.setArchived(true).catch(() => {});
      
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('✅ Ticket Fechado')
          .addFields(
            { name: 'Fechado por', value: `<@${closedBy.id}> (${closedBy.tag})` },
            { name: 'Canal', value: `#${interaction.channel.name}` },
            { name: 'Data', value: `<t:${Math.floor(Date.now() / 1000)}:F>` }
          )
          .setColor('Red');
        logChannel.send({ embeds: [embed] });
      }
    }, 5000);
  }
});

client.on(Events.ClientReady, async () => {
  const channel = await client.channels.fetch(config.ticketChannelId).catch(() => null);
  if (!channel) return;

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('open_ticket')
      .setLabel('📩 Abrir Ticket')
      .setStyle(ButtonStyle.Primary)
  );

  channel.send({
    content: '**Central de Suporte**\nClique no botão abaixo para abrir um ticket.',
    components: [row]
  }).catch(() => {});
});

client.login(config.token);
