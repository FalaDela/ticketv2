const { 
  Client, 
  GatewayIntentBits, 
  Collection, 
  Partials 
} = require('discord.js');

console.clear();

// cria o client do jeito CERTO
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.User,
    Partials.GuildMember
  ],
});

// collections
client.commands = new Collection();
client.slashCommands = new Collection();

// pega o token
const { token } = require('../config.json');

// debug obrigatório
if (!token) {
  console.error('❌ TOKEN NÃO ENCONTRADO no config.json');
  process.exit(1);
}

// handlers
require('./handler/index')(client);

const Events = require('./handler/Events');
Events.run(client);

// login
client.login(token);

// erros
process.on('unhandledRejection', (reason) => {
  console.error('🚫 unhandledRejection:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('🚫 uncaughtException:', error);
});
